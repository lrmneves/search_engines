
public class RetrievalModelLetor extends RetrievalModel  {

	@Override
	public String defaultQrySopName() {
		return new String ("#or");
	}

}
